import csv
import os

# 产品的sku，即uuid
skus = []


# 返回文件名列表
def get_file_list(files_dir):
    file_list = os.listdir(files_dir)
    if not file_list:
        return
    else:
        return file_list


# 读取某一商品的某一类评论的评分以及评论
def read_data(filename):
    # 如果以utf-8方法打开抛出异常，那么就用gbk方式打开
    try:
        with open(filename, 'r', encoding='UTF-8') as f:
            reader = csv.reader(f)
            idx = 1
            comment_score_list = []
            comment_list = []
            for data in reader:
                if len(data) < 2:
                    idx += 1
                    continue
                if (idx % 2) != 0:
                    comment_score_list.append(data[-2])
                    comment_list.append(data[-1])
                idx += 1
            return comment_score_list, comment_list
    except:
        with open(filename, 'r', encoding='gbk') as f:
            reader = csv.reader(f)
            idx = 1
            comment_score_list = []
            comment_list = []
            for data in reader:
                if len(data) < 2:
                    idx += 1
                    continue
                if (idx % 2) != 0:
                    comment_score_list.append(data[-2])
                    comment_list.append(data[-1])
                idx += 1
            return comment_score_list, comment_list


if __name__ == '__main__':
    # 手机评价的路径
    # path = 'D:\\courses\\工程实践\\爬虫数据\\phone\\phoneComments'
    # 平板评价的路径
    path = 'D:\\courses\\工程实践\\爬虫数据\\pad\\padComments'
    # 相机评价的路径
    # path = 'D:\\courses\\工程实践\\爬虫数据\\camera\\cameraComments'
    # 读取某一文件夹下的所有csv文件
    files = get_file_list(path)
    # 产品的数量(一个产品对应三个文件，好评，差评，中评)，因此产品数量 = 文件数量 / 3
    file_num = len(files) // 3
    # gc_num = 0
    # mc_num = 0
    # bc_num = 0
    # 对于每一个商品
    for i in range(file_num):
        # 从文件名获取商品的sku
        skus.append(files[i * 3].split('_')[0])
        # 每个商品有3中类型的评论，分别在三个不同的文件中
        g_comment_filename = path + '\\' + files[i * 3 + 2]
        m_comment_filename = path + '\\' + files[i * 3 + 1]
        b_comment_filename = path + '\\' + files[i * 3]
        # 好评的评分列表，好评的评论列表
        gscl, gcl = read_data(g_comment_filename)
        # 中评的评分列表，中评的评论列表
        mscl, mcl = read_data(m_comment_filename)
        # 差评的评分列表，差评的评论列表
        bscl, bcl = read_data(b_comment_filename)
        # gc_num += len(gcl)
        # mc_num += len(mcl)
        # bc_num += len(bcl)

    # 手机 -> 好评数量: 36220 中评数量: 7011 差评数量: 8904
    # 平板 -> 好评数量: 34500 中评数量: 3298 差评数量: 5717
    # 相机 -> 好评数量: 21486 中评数量: 658 差评数量: 1386
    # print("好评数量: " + str(gc_num))
    # print("中评数量: " + str(mc_num))
    # print("差评数量: " + str(bc_num))
