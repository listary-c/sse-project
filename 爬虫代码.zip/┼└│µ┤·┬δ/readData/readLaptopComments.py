import os
from openpyxl import Workbook
import re
from openpyxl import load_workbook

good_comments = []
mid_comments = []
bad_comments = []
stop_words = []
sep_good_word_list = []
sep_bad_word_list = []
label = []


# 读取所有的评论文件的文件名，文件按照创建时间递增排序
def get_file_list(file_path):
    dir_list = os.listdir(file_path)
    if not dir_list:
        return
    else:
        # 注意，这里使用lambda表达式，将文件按照最后修改时间顺序升序排列
        # os.path.getmtime() 函数是获取文件最后修改时间
        # os.path.getctime() 函数是获取文件最后创建时间
        dir_list = sorted(dir_list, key=lambda x: os.path.getmtime(os.path.join(file_path, x)))
        return dir_list


# 读取一个文件中的评论信息
def read_comments(file_path, file_name):
    path = file_path + '\\' + file_name
    wb = load_workbook(path)
    g_comments = []
    m_comments = []
    b_comments = []
    sheet1 = wb['好评']
    row = sheet1.max_row
    for i in range(2, row + 1):
        g_comments.append(sheet1.cell(row=i, column=1).value)
    # print(g_comments)
    sheet2 = wb['中评']
    row = sheet2.max_row
    for i in range(2, row + 1):
        m_comments.append(sheet2.cell(row=i, column=1).value)
    sheet3 = wb['差评']
    row = sheet3.max_row
    for i in range(2, row + 1):
        b_comments.append(sheet3.cell(row=i, column=1).value)
    return g_comments, m_comments, b_comments


if __name__ == "__main__":
    file_path = 'D:\\courses\\工程实践\\爬虫\\mytest\\数据\\commentInfo'
    file_list = get_file_list(file_path)
    # 只读取前2个excel的评论信息作为测试
    for i in range(40):
        gcl, mcl, bcl = read_comments(file_path, file_list[i])
        good_comments += gcl
        mid_comments += mcl
        bad_comments += bcl
    print(len(good_comments))
    print(len(mid_comments))
    print(len(bad_comments))
    # 读取所有的评论信息
    # for comment_file in file_list:
    #     gcl, bcl = read_comments(file_path, comment_file)
    #     good_comments += gcl
    #     bad_comments += bcl
    # 68407条好评，16769条中评+差评
    # print(len(good_comments))
    # print(len(bad_comments))
    # get_stop_words()
    # print(stop_words)
    # do_sep_word()
    # print(sep_good_word_list)
    # good_dic, bad_dic = get_word_freq()
    # res = get_topK(bad_dic, 20)
    # print(res)
