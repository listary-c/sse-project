import random

import requests, csv, time
import requests
import time
from openpyxl import load_workbook


def params(sku):
    gbl = []
    mbl = []
    bbl = []
    for i in range(100):
        params = {
            "productId": sku,
            "score": 3,
            "sortType": 5,
            "page": i,
            "pageSize": 10
        }
        gbl.append(params)

    for i in range(100):
        params = {
            "productId": sku,
            "score": 2,
            "sortType": 5,
            "page": i,
            "pageSize": 10
        }
        mbl.append(params)

    for i in range(100):
        params = {
            "productId": sku,
            "score": 1,
            "sortType": 5,
            "page": i,
            "pageSize": 10
        }
        bbl.append(params)
    return gbl, mbl, bbl


def get_data(params, c_type, sku, page_id):
    time.sleep(random.randint(1, 4))
    head = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36"
    }
    url = "https://club.jd.com/comment/skuProductPageComments.action?"
    text = requests.get(url=url, headers=head, params=params).json()
    maxPage = text['maxPage']
    data = text["comments"]

    for da in data:
        dic = {}
        dic["productColor"] = da["productColor"]
        dic["productSize"] = da["productSize"]
        dic["score"] = da["score"]
        dic["content"] = da["content"]
        filename = str(sku) + '_' + str(c_type) + '_comments.csv'
        file_path = 'D:\\courses\\工程实践\\爬虫数据\\phone\\phoneComments' + '\\' + filename
        with open(file_path, "a", encoding="utf-8") as f:
            writer = csv.DictWriter(f, dic.keys())
            writer.writerow(dic)
    return maxPage


if __name__ == "__main__":
    # 首先读取skuAndUrl.xlsx中的sku
    skus = []
    wb0 = load_workbook('D:\\courses\\工程实践\\爬虫数据\\phone\\phoneSkuAndUrl.xlsx')
    sheet = wb0['商品id与url']
    for i in range(2, 42):
        skus.append(sheet.cell(row=i, column=1).value)
    k = 0
    for sku in skus:
        if k <= 29:
            k += 1
            continue
        good_params_list = []
        mid_params_list = []
        bad_params_list = []
        good_params_list, mid_params_list, bad_params_list = params(sku)
        i = 0
        maxPage = 0
        for good_params in good_params_list:
            maxPage = get_data(good_params, 3, sku, i)
            i += 1
            if i >= maxPage:
                break
        i = 0
        maxPage = 0
        for mid_params in mid_params_list:
            maxPage = get_data(mid_params, 2, sku, i)
            i += 1
            print(maxPage)
            if i >= maxPage:
                break
        i = 0
        maxPage = 0
        for bad_params in bad_params_list:
            maxPage = get_data(bad_params, 1, sku, i)
            i += 1
            if i >= maxPage:
                break

