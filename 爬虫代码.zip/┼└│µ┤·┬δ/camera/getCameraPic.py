import requests
import random
import re
from openpyxl import load_workbook
import time

#  请求头池
user_agent = [
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; AcooBrowser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)",
    "Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.35; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
    "Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
    "Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
    "Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2; .NET CLR 3.0.04506.30)",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
    "Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2pre) Gecko/20070215 K-Ninja/2.1.1",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9) Gecko/20080705 Firefox/3.0 Kapiko/3.0",
    "Mozilla/5.0 (X11; Linux i686; U;) Gecko/20070322 Kazehakase/0.4.5",
    "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko Fedora/1.9.0.8-1.fc10 Kazehakase/0.5.6",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/535.20 (KHTML, like Gecko) Chrome/19.0.1036.7 Safari/535.20",
    "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; fr) Presto/2.9.168 Version/11.52",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.11 TaoBrowser/2.0 Safari/536.11",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.71 Safari/537.1 LBBROWSER",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; LBBROWSER)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E; LBBROWSER)",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.84 Safari/535.11 LBBROWSER",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; QQBrowser/7.0.3698.400)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; SV1; QQDownload 732; .NET4.0C; .NET4.0E; 360SE)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
    "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1",
    "Mozilla/5.0 (iPad; U; CPU OS 4_2_1 like Mac OS X; zh-cn) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8C148 Safari/6533.18.5",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:2.0b13pre) Gecko/20110307 Firefox/4.0b13pre",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:16.0) Gecko/20100101 Firefox/16.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11",
    "Mozilla/5.0 (X11; U; Linux x86_64; zh-CN; rv:1.9.2.10) Gecko/20100922 Ubuntu/10.10 (maverick) Firefox/3.6.10"
]
cookie_str = '__jdu=16017070160201880170668; shshshfpa=079e9010-73d6-4abc-a932-03f849f37279-1601707018; shshshfpb=ngW53vPIO2GEfNhopbSpjMw==; pinId=KkCVJQ6uhChLQFVFGeWK-rV9-x-f3wj7; unpl=V2_ZzNtbURSEEdyAEAHfxgOAWJTRQ9LX0scJV0UUHkcDgdhAEBeclRCFnUUR1NnGFwUZgsZWUJcRxNFCENkexhdBWMGEV5EVnMlMEsWBi8FXAduABpVRFNFEXYMQVV9GlwNZDMRXXJWcxVyCUZSeh9dBWACEVxCXkoUdQ5HU3wQbDVnCxZtRFZEF3EKT1B5Gl81sa2GiMromqXQ3uz6rpTs0O6oxuPEZ0McdQpOVXoZWwZXAiJcchYtFXQKQFJzHltIZwQTXURWRRR1D0dXehlVDGYDFFxFUEoldDhF; areaId=12; ipLoc-djd=12-988-40034-0; __jdv=76161171|kong|t_1000342893_|zssc|6bd17995-2546-4d36-836f-f42e7cc06b0b-p_3141|1622624055332; TrackID=1ORlsvdosj9zjMeHL9LQJYg7wr6J7uvatz5-aOAH8eNw7l0LaysS2CKJa5YC1ulL4lle8rcTdSqulzDeZXHZbBSn3HaXlpN7FGFjx9ajQqGI; pin=jd_7443156ce1b6f; unick=jd_7443156ce1b6f; _tp=EqXVxwNG0sehnAXkFccIMemC/UbT8hQIbvFFCDED3sg=; _pst=jd_7443156ce1b6f; shshshfp=f826da6445a0e9303a4b0f6af6f16114; __jdc=122270672; __jda=122270672.16017070160201880170668.1601707016.1623301348.1623305462.92; shshshsID=ccbef984130368b859a81c2b6423e819_2_1623306023972; __jdb=122270672.2.16017070160201880170668|92.1623305462; 3AB9D23F7A4B3C9B=Z7WT62R5MPGTIZRFIA2QGMEFTAGRTGIR23LBDGKG3ICJQSVUQ2DGVTWF7GP2442TM4OFQFURKONZR5ZQ3WEMW6JEMY'

img_urls = ['https://img12.360buyimg.com/n1/jfs/t1/106728/4/19451/302349/5e9d2e64E49bb436a/a7224d0061a46849.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/171209/1/8642/112295/603cbe22Ea99305cc/d1baaebed6eb13e9.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/124650/38/8593/77729/5f27cde1E1e9f8c00/38de3d334074b900.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/24435/18/5612/125243/5c41885bE17ee06f8/eb78a98d36949488.jpg',
            'https://img12.360buyimg.com/n1/jfs/t7006/51/329987591/125196/17ae08cc/59755188N08ffd2e1.jpg',
            'https://img12.360buyimg.com/n1/jfs/t2737/301/2095021926/171643/c331a4b7/5757aa19N796cd1ca.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/125175/17/15169/17622/5f8d5f49Ec4c2741f/db885fa7a8049652.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/128094/16/6931/291376/5f0bd9e8E1e1db064/0d2a2704c1a55c11.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/108786/33/10819/201582/5e82bbfbE63b53297/18d98cd77f9763a9.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/61108/23/11108/345405/5d89e6dcE36f697b5/dca320d27a2c9f88.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/159205/24/8951/98040/603cbce8E487bb9ec/45f1b4bdf0f277c2.jpg',
            'https://img12.360buyimg.com/n1/g14/M00/1E/1E/rBEhV1NDnwQIAAAAAAGfpQy7BH8AALiPwFfMN8AAZ-9243.jpg',
            'https://img12.360buyimg.com/n1/jfs/t20614/281/268104072/96712/87d1cefa/5b079b69Nbadd8640.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/147682/39/12347/48021/5f9a4111Ee51245c4/f7f57e492585f849.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/136540/21/20195/52061/5fd87983Ea631f280/9643cad827f97195.jpg',
            'https://img12.360buyimg.com/n1/jfs/t23638/115/1549182804/206369/7aa7a7b6/5b62c44eN578abf0f.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/152173/19/13146/90724/5ff3e159Ec59b09db/0469e092c2d08be9.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/143727/10/3443/48626/5f16d5d6Efb7e1c91/7a585406495a2c91.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/151745/14/9102/87409/5fd07c49E04b051b2/87f920309bac3f27.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/179345/21/5093/115776/60a60f28Ea305ddcc/d9f1ec66f3ece0e4.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/135818/22/20007/69175/5fd82a28E77e9bbb7/03d8cb3ceac59586.jpg',
            'https://img12.360buyimg.com/n1/jfs/t5689/87/1471260005/324147/befd4ba5/5926960cN00904afa.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/77695/40/7859/100753/5d5e3155Ea081b46e/8cc7b253cd3ca883.jpg',
            'https://img13.360buyimg.com/n5/s450x450_jfs/t1/123308/25/1061/134174/5eb917cfE04f30770/f362ecebcba59b1f.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/173648/34/1321/95248/606447c5E615dc9e6/aa0956cb62dcf2cd.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/119425/4/5451/369151/5ebe417dEa6ba47ee/1db57d94e93f8e11.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/169927/38/15620/233705/6063f20fEe27e47ae/0fb2d7725c80bd41.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/44978/38/10856/140822/5d8051d3E1f6d1379/41b2c8ff065b60ef.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/107236/20/13197/207568/5e9eaf73E54c7de01/6e5e057d9b0f0eca.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/186710/17/5474/75288/60b0e647E34b20be7/4187a18e70b53192.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1201/81/1087777321/131227/478b5ffe/55700482Nbdf3b7c6.jpg',
            'https://img11.360buyimg.com/n1/s450x450_jfs/t1/140755/24/15555/49672/5fbb5373E2fed382f/cae192555976a830.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/133521/37/8931/115269/5f4f3167Ea4c21378/697fdbef71b3a98b.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/89022/18/12746/196563/5e4e1d55E05fa4c68/4995cc0c6b0c53c7.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/130422/25/12210/100661/5f857060Efd38b046/0201d463caef79a5.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/48133/34/9795/246745/5d721e93E6180f649/4df3d68ce7d0b783.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/166968/12/15478/105661/6064344bEc3998104/b237d166e9d4fc87.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/121800/15/9964/87153/5f3a556eE934220ae/66e21749a9248e48.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/119124/34/14425/53264/5f30a6cfE3cbd143d/f5abb7a69ea538e1.jpg',
            'https://img12.360buyimg.com/n1/jfs/t1/192869/39/5427/134854/60b0658fEa8ad954e/447060d90b098f99.jpg']


def get_sku_and_url():
    wb = load_workbook('D:\\courses\\工程实践\\爬虫数据\\camera\\cameraSkuAndUrl.xlsx')
    sheet1 = wb['商品id与url']
    urls = []
    skus = []
    for i in range(2, 42):
        sku = sheet1.cell(i, 1).value
        url = sheet1.cell(i, 2).value
        urls.append(url)
        skus.append(sku)
    return urls, skus


def get_img_urls(urls):
    img_urls = []
    cnt = 0
    for url in urls:
        if cnt <= 31:
            cnt += 1
            continue
        print(url)
        time.sleep(random.randint(1, 4))
        header = {'User-Agent': random.choice(user_agent), 'cookie': cookie_str}
        r = requests.get(url, headers=header)
        regex_0 = re.compile(r'imageList:.*')
        # print(r.text)
        mo_0 = regex_0.search(r.text)
        temp = mo_0.group()
        # print(temp)
        regex_1 = re.compile(r',\".*\.jpg')
        mo_1 = regex_1.search(temp)
        text = mo_1.group()
        part1 = 'https://img12.360buyimg.com/n1/'
        end = 0
        for i in range(2, len(text)):
            if text[i] == '\"':
                break
            end = i
        part2 = text[2:end + 1]
        img_url = part1 + part2
        img_urls.append(img_url)
        print(img_urls)
        cnt += 1
    return img_urls


def download_imgs(img_urls, skus):
    for i in range(len(skus)):
        time.sleep(random.randint(2, 5))
        header = {'User-Agent': random.choice(user_agent)}
        filepath = 'D:\\courses\\工程实践\\结题\\img\\camera\\' + skus[i] + '.png'
        r = requests.get(img_urls[i], headers=header, stream=True)
        if r.status_code == 200:
            open(filepath, 'wb').write(r.content)  # 将内容写入图片
    print("done")


if __name__ == '__main__':
    urls, skus = get_sku_and_url()
    # img_urls = get_img_urls(urls)
    download_imgs(img_urls, skus)
