# coding:utf-8
from openpyxl import load_workbook


def get_sku():
    wb = load_workbook('D:\\courses\\工程实践\\爬虫数据\\pad\\padSkuAndUrl.xlsx')
    sheet1 = wb['商品id与url']
    skus = []
    for i in range(2, 42):
        sku = sheet1.cell(i, 1).value
        skus.append(sku)
    return skus


def get_product_price():
    wb = load_workbook('D:\\courses\\工程实践\\爬虫数据\\pad\\padProductInfo.xlsx')
    sheet1 = wb['商品信息']
    urls = []
    prices = []
    product_names = []
    for i in range(2, 42):
        url = sheet1.cell(i, 1).value
        price = sheet1.cell(i, 5).value
        name = sheet1.cell(i, 3).value
        product_names.append(name)
        urls.append(url)
        prices.append(price)
    return urls, prices, product_names


def get_sqls(skus, product_names, prices):
    # INSERT INTO `shopping_product` VALUES ('88', '电脑', '5', '25', '23', '23', '23', '100', 'u=1555859618,928586979&fm=111&gp=0.jpg', '水电费第三方', '2018-03-25 22:29:32', '2018-03-25 22:29:32', '1', '0');
    # INSERT INTO `shopping_product` VALUES ('100008699547', '联想(Lenovo)小新Air15 2021锐龙版全面屏办公轻薄笔记本电脑(8核R7-4800U 16G 512G 100%sRGB 高色域)深空灰', '5', '25', '4798.00', '4798.00', '999''10000', 'pic_addr''联想(Lenovo)小新Air15 2021锐龙版全面屏办公轻薄笔记本电脑(8核R7-4800U 16G 512G 100%sRGB 高色域)深空灰', '2021-04-20 12:30:30''2021-04-20 12:30:30''1', '0');
    sqls = []
    part1 = 'INSERT INTO `shopping_product` VALUES ('
    for i in range(40):
        id = skus[i]
        name = product_names[i]
        cost_price = prices[i]
        sell_price = prices[i]

        click_count = str(10000 - i * 100)
        sql = part1 + "'" + id + "'" + ', ' + "'" + name + "', " + "'5', '24', " + "'" + cost_price + "', " + "'" + sell_price + "', " + \
              "'999', " + "'" + click_count + "', " + "'./" + id + '.png' + "', " + "'" + name + "', " + "\'2021-04-20 12:30:30\', " + \
              "\'2021-05-15 10:20:15\', " + "'1', '0');"
        sqls.append(sql)
    print(sqls)


if __name__ == '__main__':
    skus = get_sku()
    urls, prices, product_names = get_product_price()
    get_sqls(skus, product_names, prices)
