from selenium import webdriver
from lxml import etree
import time
from openpyxl import Workbook

start = time.perf_counter()
urls = []

# ########################
# 爬取商品的sku和url
# ########################

# 使用selenium模拟人为访问页面,获取数据
def spider_jd(url):
    # ChromeOptions() 函数中有谷歌浏览器的一些配置
    options = webdriver.ChromeOptions()
    # 告诉谷歌这里用的是无头模式
    options.add_argument('headless')
    # 创建谷歌浏览器对象
    driver = webdriver.Chrome('D:\develop\chromedriver\chromedriver.exe')
    # 打开谷歌浏览器,进入指定网址的页面
    driver.get(url)
    # 模拟下拉页面动作,是动态页面加载
    driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")
    # 停顿2.5秒等待页面加载完毕！！！（必须留有页面加载的时间，否则部分浏览器获得的源代码会不完整。）
    time.sleep(2.5)

    # 相当于 request.get(url, headers=header)
    source = driver.page_source
    print(source)
    # 构造了一个XPath解析对象并对HTML文本进行自动修正。
    html1 = etree.HTML(source)
    # 提取href
    href = html1.xpath('//div[@class="p-img"]/a/@href')

    # 仅保存前60个值，k值每次循环自增60
    for hr in href:
        if hr[:6] != 'https:' or hr[:6] != 'http:':  # 判断是否为https:开头项，为否则添加https:头
            urls.append('https:' + hr)
        else:
            urls.append(hr)
    del urls[k:]
    driver.close()  # 爬取完毕关闭浏览器

k = 60

def getEnd(url):
    str = url[20:]
    endIdx = 20
    for c in str:
        if c < '0' or c > '9':
            break
        endIdx += 1
    return endIdx


for i in range(1, 2):
    url = 'https://search.jd.com/Search?keyword=%E5%B9%B3%E6%9D%BF%E7%94%B5%E8%84%91&enc=utf-8&qrst=1&rt=1&stop=1&vt=2&suggest=1.his.0.0&psort=3&page={}&s=61&click=0'.format(
        (i * 2) - 1)
    spider_jd(url)
    k = k + 60

# 实例化
wb = Workbook()
# 激活 worksheet
ws = wb.active
ws.title = u'商品id与url'
# 向第一个sheet页写数据吧
ws.cell(row=1, column=1).value = "商品id"
ws.cell(row=1, column=2).value = "url"
r = 2
for url in urls:
    ws.cell(row=r, column=1).value = url[20: getEnd(url)]
    ws.cell(row=r, column=2).value = url
    r += 1
# 工作簿保存到磁盘
wb.save('D:\\courses\\工程实践\\爬虫数据\\pad\\padSkuAndUrl.xlsx')
print('共爬取{}条数据，爬取完毕关闭浏览器'.format(len(urls)))
