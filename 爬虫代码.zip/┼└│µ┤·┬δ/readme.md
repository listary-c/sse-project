# 爬虫代码说明

- 编译器：PyCharm
- 库版本：
    - lxml：4.6.2
    - openpyxl：3.0.5
    - xlwt：1.3.0
    - xlrd：2.0.1
- camera 目录，此目录存放爬取照相机评论的相关代码
    - getCameraSkuAndUrl.py 代码在商品搜索页，爬取商品的 sku 以及 url，并且爬取商品的销量是从高到低的，将爬取到的信息存放在 excel 中
    - getCameraProductInfo.py 代码爬取商品品牌，商品名称，商品信息，当前价格，指导价格，最高价格，概要评论信息，将爬取到的信息存放在 excel 中
    - getCameraComments.py 爬取商品的评论信息，包括好评，中评和差评信息，分别存放在 csv 文件中
    - getInsertCameraSQL.py 从上面的 excel 中读取商品的名称，价格等信息，拼接得到 sql 语句，提供给系统
    - getCameraPic.py 爬取商品对应的图片信息
- laptop 目录，此目录存放爬取笔记本电脑评论的相关代码
    - getLaptopSkuAndUrl.py 代码在商品搜索页，爬取商品的 sku 以及 url，并且爬取商品的销量是从高到低的，将爬取到的信息存放在 excel 中
    - getLaptopProductInfo.py 代码爬取商品品牌，商品名称，商品信息，当前价格，指导价格，最高价格，概要评论信息，将爬取到的信息存放在 excel 中
    - getLaptopComments.py 爬取商品的评论信息，包括好评，中评和差评信息，将爬取到的信息存放在 excel 中，这份代码与 camera 中的爬取评论信息的思路一致，只是写的方式不同，这份代码在 1 月 26 号运行，爬取了笔记本电脑的信息，但是于 3 月份爬取到的数据为空
    - getInsertLaptopSQL.py 从上面的 excel 中读取商品的名称，价格等信息，拼接得到 sql 语句，提供给系统
    - getLaptopPic.py 爬取商品对应的图片信息
- pad 目录，此目录存放爬取平板评论的相关代码
    - 每个代码执行的功能与 camera 中对应的文件类似
- phone 目录，此目录存放爬取笔记本电脑评论的相关代码
    - 每个代码执行的功能与 camera 中对应的文件类似
- readData 目录
    - readLaptopComments.py 从存放笔记本电脑评价信息的 excel 文件中读取评论，为计算商品相似度做铺垫
    - readOtherComments.py 从存放平板，相机，手机评价信息的 csv 文件中读取评论，为计算商品相似度做铺垫
- 爬虫数据目录存放爬取到的数据

