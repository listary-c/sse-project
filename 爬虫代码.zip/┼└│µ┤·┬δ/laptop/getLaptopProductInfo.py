import requests
from lxml import etree
import json
from multiprocessing.dummy import Pool as ThreadPool
import random
import time
from openpyxl import Workbook
from openpyxl import load_workbook

# 实例化
wb = Workbook()
# 激活 worksheet
ws = wb.active
ws.title = u'商品信息'
# 向第一个sheet页写数据吧
ws.cell(row=1, column=1).value = "商品url"
ws.cell(row=1, column=2).value = "品牌"
ws.cell(row=1, column=3).value = "商品名称"
ws.cell(row=1, column=4).value = "商品详情"
ws.cell(row=1, column=5).value = "当前价格"
ws.cell(row=1, column=6).value = "指导价格"
ws.cell(row=1, column=7).value = "最高价格"
ws.cell(row=1, column=8).value = "评论信息"
#  请求头池
user_agent = [
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; AcooBrowser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)",
    "Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.35; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
    "Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
    "Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
    "Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2; .NET CLR 3.0.04506.30)",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
    "Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2pre) Gecko/20070215 K-Ninja/2.1.1",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9) Gecko/20080705 Firefox/3.0 Kapiko/3.0",
    "Mozilla/5.0 (X11; Linux i686; U;) Gecko/20070322 Kazehakase/0.4.5",
    "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko Fedora/1.9.0.8-1.fc10 Kazehakase/0.5.6",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/535.20 (KHTML, like Gecko) Chrome/19.0.1036.7 Safari/535.20",
    "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; fr) Presto/2.9.168 Version/11.52",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.11 TaoBrowser/2.0 Safari/536.11",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.71 Safari/537.1 LBBROWSER",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; LBBROWSER)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E; LBBROWSER)",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.84 Safari/535.11 LBBROWSER",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; QQBrowser/7.0.3698.400)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; SV1; QQDownload 732; .NET4.0C; .NET4.0E; 360SE)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
    "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1",
    "Mozilla/5.0 (iPad; U; CPU OS 4_2_1 like Mac OS X; zh-cn) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8C148 Safari/6533.18.5",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:2.0b13pre) Gecko/20110307 Firefox/4.0b13pre",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:16.0) Gecko/20100101 Firefox/16.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11",
    "Mozilla/5.0 (X11; U; Linux x86_64; zh-CN; rv:1.9.2.10) Gecko/20100922 Ubuntu/10.10 (maverick) Firefox/3.6.10"
]
error_counter = []
error_ids = []
cookie_str = '__jdu=16017070160201880170668; shshshfpa=079e9010-73d6-4abc-a932-03f849f37279-1601707018; shshshfpb=ngW53vPIO2GEfNhopbSpjMw==; pinId=KkCVJQ6uhChLQFVFGeWK-rV9-x-f3wj7; unpl=V2_ZzNtbURSEEdyAEAHfxgOAWJTRQ9LX0scJV0UUHkcDgdhAEBeclRCFnUUR1NnGFwUZgsZWUJcRxNFCENkexhdBWMGEV5EVnMlMEsWBi8FXAduABpVRFNFEXYMQVV9GlwNZDMRXXJWcxVyCUZSeh9dBWACEVxCXkoUdQ5HU3wQbDVnCxZtRFZEF3EKT1B5Gl81sa2GiMromqXQ3uz6rpTs0O6oxuPEZ0McdQpOVXoZWwZXAiJcchYtFXQKQFJzHltIZwQTXURWRRR1D0dXehlVDGYDFFxFUEoldDhF; areaId=12; ipLoc-djd=12-988-40034-0; __jdv=76161171|kong|t_1000342893_|zssc|6bd17995-2546-4d36-836f-f42e7cc06b0b-p_3141|1622624055332; TrackID=1ORlsvdosj9zjMeHL9LQJYg7wr6J7uvatz5-aOAH8eNw7l0LaysS2CKJa5YC1ulL4lle8rcTdSqulzDeZXHZbBSn3HaXlpN7FGFjx9ajQqGI; pin=jd_7443156ce1b6f; unick=jd_7443156ce1b6f; _tp=EqXVxwNG0sehnAXkFccIMemC/UbT8hQIbvFFCDED3sg=; _pst=jd_7443156ce1b6f; shshshfp=f826da6445a0e9303a4b0f6af6f16114; __jda=122270672.16017070160201880170668.1601707016.1623301348.1623305462.92; 3AB9D23F7A4B3C9B=Z7WT62R5MPGTIZRFIA2QGMEFTAGRTGIR23LBDGKG3ICJQSVUQ2DGVTWF7GP2442TM4OFQFURKONZR5ZQ3WEMW6JEMY; shshshsID=ccbef984130368b859a81c2b6423e819_11_1623308375098; __jdb=122270672.11.16017070160201880170668|92.1623305462; __jdc=122270672'


def get_data(product_id, row):  # 获取商品详细数据
    try:
        p_url = 'https://item.jd.com/' + product_id + '.html'
        ws.cell(row=row + 2, column=1).value = p_url
        header = {'User-Agent': random.choice(user_agent), 'cookie': cookie_str}
        r = requests.get(p_url, headers=header)
        detail = etree.HTML(r.text)  # str转HTML
        product_name = detail.xpath(
            '//*[@id="detail"]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/text()')
        print(product_name)
        ws.cell(row=row + 2, column=3).value = product_name[0]
        product_brand = detail.xpath('//*[@id="detail"]/div[2]/div[1]/div[1]/ul[1]/li[1]/a/text()')  # 商品品牌
        ws.cell(row=row + 2, column=2).value = product_brand[0]
        product_info = detail.xpath('//*[@id="detail"]/div[2]/div[1]/div[1]/ul[2]/li/text()')  # 商品编号

        ws.cell(row=row + 2, column=4).value = ', '.join(product_info)
        time.sleep(1)
        # 请求价格信息json
        p = requests.get('https:' + '//p.3.cn/prices/mgets?skuIds=J_' + product_id, headers=header)
        # 请求商品价格json
        [product_dict] = json.loads(p.text)  # 获取商品价格
        product_m_price = product_dict['m']
        product_price = product_dict['p']

        product_o_price = product_dict['op']
        time.sleep(1)
        # 请求评论信息json
        icon = requests.get(
            'https://club.jd.com/comment/productPageComments.action?callback=fetchJSON_comment98&productId=' \
            + product_id + '&score=0&sortType=5&page=0&pageSize=10',
            headers=header)

        comment_ic = json.loads(icon.text.split('hotCommentTagStatistics":')[-1].split(',"jwotestProduct')[0])
        icon = []
        for ic in comment_ic:
            comment_ic_name = ic['name']
            comment_ic_num = ic['count']
            comment_icon = comment_ic_name + '(' + str(comment_ic_num) + ')'
            icon.append(comment_icon)
        comment_icon_all = ','.join(icon)

        ws.cell(row=row + 2, column=5).value = product_price
        ws.cell(row=row + 2, column=6).value = product_o_price
        ws.cell(row=row + 2, column=7).value = product_m_price
        ws.cell(row=row + 2, column=8).value = comment_icon_all
        print("- - - " + str(row))

    except Exception:
        error_ids.append(row)
        error_counter.append(error_counter)


if __name__ == "__main__":
    # 首先读取skuAndUrl.xlsx中的url
    urls = []
    ids = []
    wb0 = load_workbook('D:\\courses\\工程实践\\爬虫\\mytest\\数据\\productInfo\\skuAndUrl.xlsx')
    sheet = wb0['商品id与url']
    for i in range(2, 42):
        ids.append(sheet.cell(row=i, column=1).value)
        urls.append(sheet.cell(row=i, column=2).value)

    start = time.perf_counter()
    for i in range(40):
        url_id = str(ids[i])
        get_data(url_id, i)
        time.sleep(random.randint(1, 3))

    end = time.perf_counter()

    print(error_ids)
    for id in error_ids:
        url_id = str(ids[id])
        get_data(url_id, id)
        time.sleep(random.randint(1, 3))
        pass
    # 工作簿保存到磁盘
    wb.save('laptop_productInfo.xlsx')
    # print('\n程序完成！\n共爬取{}件商品数据，失败{}件，耗时{}s。'.format(i-1, j-1, end-start))

    print('\n程序完成！\n累计失败件数为：{}件!\n累计耗时{}s。'.format(len(error_counter), end - start))
