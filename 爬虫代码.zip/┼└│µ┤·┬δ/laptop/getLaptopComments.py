import datetime
import json
import re
import requests
import time
import random

import xlwings as xw
from openpyxl import load_workbook

# 首先读取skuAndUrl.xlsx中的url
urls = []
wb0 = load_workbook('./skuAndUrl.xlsx')
sheet = wb0['商品id与url']
for i in range(2, 602):
    urls.append(sheet.cell(row=i, column=2).value)

user_agent = [
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; AcooBrowser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)",
    "Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.35; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
    "Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
    "Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
    "Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2; .NET CLR 3.0.04506.30)",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
    "Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2pre) Gecko/20070215 K-Ninja/2.1.1",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9) Gecko/20080705 Firefox/3.0 Kapiko/3.0",
    "Mozilla/5.0 (X11; Linux i686; U;) Gecko/20070322 Kazehakase/0.4.5",
    "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko Fedora/1.9.0.8-1.fc10 Kazehakase/0.5.6",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/535.20 (KHTML, like Gecko) Chrome/19.0.1036.7 Safari/535.20",
    "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; fr) Presto/2.9.168 Version/11.52",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.11 TaoBrowser/2.0 Safari/536.11",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.71 Safari/537.1 LBBROWSER",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; LBBROWSER)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E; LBBROWSER)",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.84 Safari/535.11 LBBROWSER",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; QQBrowser/7.0.3698.400)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; SV1; QQDownload 732; .NET4.0C; .NET4.0E; 360SE)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
    "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1",
    "Mozilla/5.0 (iPad; U; CPU OS 4_2_1 like Mac OS X; zh-cn) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8C148 Safari/6533.18.5",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:2.0b13pre) Gecko/20110307 Firefox/4.0b13pre",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:16.0) Gecko/20100101 Firefox/16.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11",
    "Mozilla/5.0 (X11; U; Linux x86_64; zh-CN; rv:1.9.2.10) Gecko/20100922 Ubuntu/10.10 (maverick) Firefox/3.6.10"
]

def getRandomHeader():
    return random.choice(user_agent)

s = requests.session()
i = 1
for m in range(67, 600):
    myurl = urls[m]
    product_url = myurl
    product_id_find = re.compile('https://item.jd.com/(.*?).html').findall(product_url)
    product_id = product_id_find[0]

    start_content_page = 0  # 起始抓取页码,0是第一页

    time_now = datetime.datetime.now().strftime('%Y%m%d%H%M')
    save_file_name = 'D:\\courses\\工程实践\\爬虫\\mytest\\xlsxss\\' + product_id + '京东评价' + time_now
    # 抓取当前评论，可能是合并多个SKU的评论
    url_all = 'https://sclub.jd.com/comment/productPageComments.action'

    # 抓取当前SKU评论，相当于京东中勾选只看当前商品评论
    url_sku = 'https://club.jd.com/comment/skuProductPageComments.action'

    #  只抓取当前SKU评论
    url = url_sku

    headers = {
        'user-agent': '',
        'referer': ''
    }

    data = {
        'productId': '',
        'score': 0,  # 抓取中评为2 差评为1 好评为3 所有为0
        'sortType': 5,  # 5表示按照推荐排序，6表示按照时间排序
        'pageSize': 10,  # 单页最多显示条数，最多支持10条
        'isShadowSku': 0,
        'page': 0,  # 对应抓取的页面0-99，京东只允许抓取100页，所以最多抓取1000条
        'fold': 1
    }

    data['productId'] = product_id
    data['page'] = start_content_page
    headers['user-agent'] = random.choice(user_agent)
    headers['referer'] = 'https://item.jd.com/' + product_id + '.html'

    # 读取模板，Excel模板
    wb = xw.Book(r'D:\\courses\\工程实践\\爬虫\\mytest\\xlsxss\\mytemplate.xlsx')
    sheet_summary = wb.sheets['评价概况']

    # 抓取评价概要信息
    t = s.get(url, params=data, headers=headers).text
    j = json.loads(t)
    shop_link = 'https://item.jd.com/%s.html' % product_id
    print('开始抓取：' + shop_link)
    sheet_summary.range('B1').add_hyperlink(shop_link, shop_link, '提示：点击访问商品详情页')
    sheet_summary.range('B2').value = j['productCommentSummary']['goodRate']
    sheet_summary.range('B3').value = j['productCommentSummary']['commentCount']
    sheet_summary.range('B4').value = j['productCommentSummary']['goodCount']
    sheet_summary.range('B5').value = j['productCommentSummary']['generalCount']
    sheet_summary.range('B6').value = j['productCommentSummary']['poorCount']
    sheet_summary.range('B7').value = j['productCommentSummary']['showCount']
    sheet_summary.range('B8').value = j['productCommentSummary']['videoCount']
    sheet_summary.range('B9').value = j['productCommentSummary']['afterCount']
    sheet_summary.range('D2').value = j['productCommentSummary']['averageScore']
    sheet_summary.range('D3').value = j['productCommentSummary']['score1Count']
    sheet_summary.range('D4').value = j['productCommentSummary']['score2Count']
    sheet_summary.range('D5').value = j['productCommentSummary']['score3Count']
    sheet_summary.range('D6').value = j['productCommentSummary']['score4Count']
    sheet_summary.range('D7').value = j['productCommentSummary']['score5Count']
    sheet_summary.range('B10').value = j['imageListCount']
    sheet_summary.range('D11').value = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    wb.save(save_file_name)

    sheets_array = ['好评', '中评', '差评']
    data_score = 3
    for sheet_num in sheets_array:
        sheet_comment = wb.sheets[sheet_num]
        sheet_comment.activate()
        data['score'] = data_score
        data_score -= 1
        line_num = 2
        try_time = 6  # 抓取为空时的重试次数
        data['page'] = 0
        while True:
            try:
                headers['user-agent'] = random.choice(user_agent)
                st = random.randint(1, 4)
                time.sleep(st)
                t = s.get(url, params=data, headers=headers).text
            except Exception as e:
                print(e)
                time.sleep(random.randint(1, 4))
                continue
            flag = re.search('content', t)
            # print(flag)
            if flag is None:
                last_shop_page = data['page']
                print("抓取停止，最后页码为：" + str(last_shop_page))
                try_time -= 1
                if try_time == 0:
                    break
            else:
                j = json.loads(t)
                maxPage = j['maxPage']
                commentSummary = j['comments']
                for comment in commentSummary:
                    score = comment['score']
                    content = comment['content']  # 评论内容
                    referenceName = comment['referenceName']
                    try:
                        productColor = comment['productColor']  # 部分商品没有颜色属性
                    except Exception as e:
                        productColor = ''
                        continue
                    comment_range = 'A' + str(line_num)
                    sheet_comment.range(comment_range).value = [content, score, referenceName, productColor]
                    line_num += 1
                print('正在抓取页面:' + str(data['page']) + '总页面：' + str(maxPage))
                data['page'] += 1
        #         # time.sleep(1)

    sheet_summary.range('B1').add_hyperlink(shop_link, referenceName, '提示：点击访问商品详情页')
    wb.sheets['评价概况'].activate()
    wb.save(save_file_name)
    wb.close()
    print('\n\n- - - - ' + str(i) + ' - - - -\n\n')
    i += 1
    # app.quit()
